from django.shortcuts import render, redirect

# Create your views here.
from django.http import HttpResponse, request


def login(request):
    context = {}
    return render(request, 'kibu/login.html', context)